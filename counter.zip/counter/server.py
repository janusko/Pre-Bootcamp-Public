from flask import Flask, render_template, request, redirect, session


app = Flask(__name__)
app.secret_key = 'keep it secret, keep it safe'



@app.route('/')
def index():
    if "count" not in session:
        session['count'] = 1
    else:
        session['count'] +=1
    return render_template("index.html")

@app.route('/submit')
def submit():
    return redirect('/')

@app.route('/add_two')
def two():
    session['count'] += 1
    return redirect('/')

@app.route('/destroy_session')
def destory():
    session.pop('count')
    return redirect('/')


if__name__=="__main__":
    app.run(debug=True)